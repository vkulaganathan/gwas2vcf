The tool gwas2vcf can convert GWAS results files, like the .tsv.bgz files from UK Biobank studies, into the standard VCF 4.0 format.

For best results, it's recommended to create a virtual environment with Python 3.11.6, as that's the version this tool was tested with.

USAGE:: $ gwas2vcf -i INPUT -o OUTPUT

For help:: $ gwas2vcf -h

